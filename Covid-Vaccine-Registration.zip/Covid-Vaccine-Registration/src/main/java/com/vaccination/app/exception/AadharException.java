package com.vaccination.app.exception;

public class AadharException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AadharException(String msg) {
		super(msg);
	}
}
