package com.vaccination.app.exception;

public class DoseException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DoseException(String msg) {
		super(msg);
	}
}
