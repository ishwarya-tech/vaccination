package com.vaccination.app.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vaccination.app.Entity.Admin;
import com.vaccination.app.Entity.AdminLoginDTO;
import com.vaccination.app.Entity.AdminPasswordDTO;
import com.vaccination.app.Entity.Dose;
import com.vaccination.app.Entity.User;
import com.vaccination.app.Entity.Vaccine;
import com.vaccination.app.Entity.VaccineCenter;
import com.vaccination.app.exception.AdminException;
import com.vaccination.app.exception.DoseException;
import com.vaccination.app.exception.UserException;
import com.vaccination.app.exception.VaccineCenterException;
import com.vaccination.app.exception.VaccineException;
import com.vaccination.app.service.AdminService;
import com.vaccination.app.service.DoseService;
import com.vaccination.app.service.UserService;
import com.vaccination.app.service.VaccineCenterService;
import com.vaccination.app.service.VaccineService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	private AdminService adminService;

	@Autowired
	private VaccineService vaccineService;

	@Autowired
	private VaccineCenterService vaccineCenterService;

	@Autowired
	private UserService userService;

	@Autowired
	private DoseService doseService;

	// Admin register
	@PostMapping("/register")
	public Admin registerAdmin(@Valid @RequestBody Admin a) throws AdminException {
		return adminService.registerAdmin(a);
	}

	// Admin login
	@PostMapping("/login")
	public Admin loginAdmin(@Valid @RequestBody AdminLoginDTO adminLoginDTO) throws AdminException {
		return adminService.loginAdmin(adminLoginDTO);
	}

	// Admin logout
//	@PostMapping("/logout/{mob}")
//	public Admin logoutAdmin(@Valid @PathVariable("mob") String mobile) throws AdminException {
//		return adminService.logoutAdmin(adminService.adminSession(mobile).getUuid());
//	}

	// Update admin
//	@PutMapping("/update")
//	public Admin updatePassword(@Valid @RequestBody AdminPasswordDTO aPassDto) throws AdminException {
//		return adminService.updatePassword(aPassDto);
//	}

	// get all vaccine details
	@GetMapping("/vaccines")
	public List<Vaccine> getAllVaccine() throws VaccineException {
		return vaccineService.getAllVaccine();
	}

	// get all vaccine center details
	@GetMapping("/vaccinecenters")
	public List<VaccineCenter> getAllVaccineCenter() throws VaccineCenterException {
		return vaccineCenterService.getAllVaccineCenter();
	}

	// add vaccine
	@PostMapping("/vaccine")
	public Vaccine addVaccine(@Valid @RequestBody Vaccine v) throws AdminException, VaccineException {
		return vaccineService.addVaccine(v);
	}

	// add vaccine center
	@PostMapping("/vaccinecenter")
	public VaccineCenter addVaccineCenter(@Valid @RequestBody VaccineCenter vc) throws VaccineCenterException {
		return vaccineCenterService.addVaccineCenter(vc);
	}

//	// delete vaccine
//	@DeleteMapping("/vaccine/{id}")
//	public Vaccine deleteVaccine(@Valid @PathVariable("id") Integer id)
//			throws AdminException, VaccineException {
//		return vaccineService.deleteVaccine(id);
//	}
//
//	// delete vaccine center
//	@DeleteMapping("/vaccinecenter/{id}")
//	public VaccineCenter deleteVaccineCenter(@Valid @PathVariable("id") Integer id)
//			throws AdminException, VaccineCenterException {
//		return vaccineCenterService.deleteVaccineCenter(id);
//	}

	// Make vaccine available
	@PutMapping("/vaccineA/{id}")
	public Vaccine makeVaccineAvailable(@Valid @PathVariable("id") Integer id) throws VaccineException {
		return vaccineService.makeVaccineAvailable(id);
	}

	// Make vaccine unavailable
	@PutMapping("/vaccineU/{id}")
	public Vaccine makeVaccineUnavailable(@Valid @PathVariable("id") Integer id) throws VaccineException {
		return vaccineService.makeVaccineUnavailable(id);
	}

	// Make vaccine center available
	@PutMapping("/vaccineCenterA/{vcid}")
	public VaccineCenter makeVaccineCenterAvailable(@Valid @PathVariable("vcid") Integer vcid)
			throws VaccineCenterException {
		return vaccineCenterService.makeVaccineCenterAvailable(vcid);
	}

	// Make vaccine center unavailable
	@PutMapping("/vaccineCenterU/{vcid}")
	public VaccineCenter makeVaccineCenterUnavailable(@Valid @PathVariable("vcid") Integer vcid)
			throws VaccineCenterException {
		return vaccineCenterService.makeVaccineCenterUnavailable(vcid);
	}

	// Will update dose status as completed
	@PutMapping("/doseStatus/{doseId}")
	public Dose updateDoseStatus(@Valid @PathVariable("doseId") Integer doseId) throws DoseException {
		return doseService.updateDoseStatus(doseId);
	}

	// get all Applicant details
	@GetMapping("/users")
	public List<User> getAllUsers() throws UserException {
		return userService.getAllUsers();
	}

	// delete applicant details
	@DeleteMapping("/user/{id}")
	public Boolean deleteUser(@Valid @PathVariable("id") Integer id) throws AdminException, UserException {
		return userService.deleteUser(id);
	}

}
