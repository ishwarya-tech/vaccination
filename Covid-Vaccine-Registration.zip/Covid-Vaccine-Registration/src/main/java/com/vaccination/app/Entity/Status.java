package com.vaccination.app.Entity;

public enum Status {
	//Booking Status
	CANCELED,
	PENDING,
	COMPLETED
}
