package com.vaccination.app.exception;

public class AdminException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminException(String msg) {
		super(msg);
	}
}
