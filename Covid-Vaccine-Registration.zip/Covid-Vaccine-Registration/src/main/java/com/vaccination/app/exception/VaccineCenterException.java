package com.vaccination.app.exception;

public class VaccineCenterException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VaccineCenterException(String msg) {
		super(msg);
	}
}
